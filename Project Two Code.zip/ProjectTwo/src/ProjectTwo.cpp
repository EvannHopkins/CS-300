#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <algorithm>

class Course {
public:
    std::string courseNumber;
    std::string name;
    std::vector<std::string> prerequisites;
};

std::unordered_map<std::string, Course> courseTable;

void loadDataStructure(const std::string& fileName) {
    // Open the input file
    std::ifstream file(fileName);
    if (!file.is_open()) {
        std::cout << "Error opening file." << std::endl;
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Parse the line into courseNumber, name, and prerequisites
        std::istringstream iss(line);
        std::string courseNumber, name, prerequisite;
        std::getline(iss, courseNumber, ',');
        std::getline(iss, name, ',');
        Course course;
        course.courseNumber = courseNumber;
        course.name = name;
        while (std::getline(iss, prerequisite, ',')) {
            course.prerequisites.push_back(prerequisite);
        }
        // Store the course object in the courseTable
        courseTable[courseNumber] = course;
    }
    // Close the file
    file.close();

    std::cout << "Data loaded successfully." << std::endl;
}

void printCourseList() {
    // Check if the courseTable is empty
    if (courseTable.empty()) {
        std::cout << "Course table is empty." << std::endl;
        return;
    }

    // Collect course numbers and sort them alphabetically
    std::vector<std::string> courseNumbers;
    for (const auto& entry : courseTable) {
        courseNumbers.push_back(entry.first);
    }
    std::sort(courseNumbers.begin(), courseNumbers.end());

    // Print the sorted course list
    std::cout << "Course List:" << std::endl;
    for (const auto& courseNumber : courseNumbers) {
        std::cout << courseNumber << ", " << courseTable[courseNumber].name << std::endl;
    }
}

void printCourseInfo(const std::string& courseNumber) {
    // Check if the specified courseNumber exists in the courseTable
    if (courseTable.find(courseNumber) == courseTable.end()) {
        std::cout << "Course not found." << std::endl;
        return;
    }

    // Print course information and prerequisites
    const Course& course = courseTable[courseNumber];
    std::cout << course.courseNumber << ", " << course.name << std::endl;
    if (!course.prerequisites.empty()) {
        std::cout << "Prerequisites:";
        for (const auto& prerequisite : course.prerequisites) {
            std::cout << " " << prerequisite;
        }
        std::cout << std::endl;
    }
}

int main() {
    int choice;
    std::string fileName;

    std::cout << "Welcome to the course planner." << std::endl;

    while (true) {
        // Display the main menu
        std::cout << "1. Load Data Structure." << std::endl;
        std::cout << "2. Print Course List." << std::endl;
        std::cout << "3. Print Course." << std::endl;
        std::cout << "4. Exit" << std::endl;
        std::cout << "What would you like to do? ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                // Load course data from file
                std::cout << "Enter file name: ";
                std::cin >> fileName;
                loadDataStructure(fileName);
                break;
            case 2:
                // Print the course list
                printCourseList();
                break;
            case 3:
                // Print course information
                std::cout << "What course do you want to know about? ";
                std::cin >> fileName;
                printCourseInfo(fileName);
                break;
            case 4:
                // Exit the program
                std::cout << "Thank you for using the course planner!" << std::endl;
                return 0;
            default:
                // Invalid menu choice
                std::cout << choice << " is not a valid option." << std::endl;
        }

        // Clear the input buffer
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    return 0;
}
